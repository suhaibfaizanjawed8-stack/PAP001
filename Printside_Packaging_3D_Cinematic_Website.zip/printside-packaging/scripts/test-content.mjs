import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const source=fs.readFileSync(path.join(root,'src/app.js'),'utf8').split('let scrollScheduled=false;')[0];
const ctx=vm.createContext({location:{pathname:'/',search:''},URLSearchParams,document:{},window:{}});
vm.runInContext(source,ctx);
const names=['home','about','products','capabilities','innovation','quality','industries','contact'];
const allRoutes=new Set(['/',...names.slice(1).map(n=>n==='about'?'/about':`/${n}`)]);
const productIds=vm.runInContext('P.map(p=>p.id)',ctx);
for(const id of productIds) allRoutes.add('/products/'+id);
let totalLinks=0;
for(const name of names){
  const html=vm.runInContext(`${name}()`,ctx);
  if(!html.includes('<main id="main">')||!html.includes('<h1')) throw Error('Missing main/heading for '+name);
  const links=[...html.matchAll(/href="(\/[^"]*)"/g)].map(m=>m[1].split('?')[0].split('#')[0]);
  for(const href of links) if(!allRoutes.has(href))throw Error(name+' broken route '+href);
  totalLinks+=links.length;
  console.log('PASS page:',name,'links:',links.length,'bytes:',html.length);
}
for(const id of productIds){
 const html=vm.runInContext(`detail('${id}')`,ctx);
 if(!html.includes('Enquire about this product'))throw Error('Missing quote link '+id);
 const file=path.join(root,'public/assets',id+'.svg');if(!fs.existsSync(file))throw Error('Missing asset '+id);
 console.log('PASS product:',id);
}
console.log('PASS: tested',names.length,'core pages,',productIds.length,'product pages,',totalLinks,'internal links and local assets.');
