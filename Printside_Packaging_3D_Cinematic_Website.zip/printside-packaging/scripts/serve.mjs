import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const pub = process.argv.includes('--dist') ? path.join(root,'dist') : root;
const port = Number(process.env.PORT || 4173);
const mime={'.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.html':'text/html; charset=utf-8','.svg':'image/svg+xml','.json':'application/json','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp'};
http.createServer(async(req,res)=>{
  const pathname = new URL(req.url,`http://${req.headers.host}`).pathname;
  if(pathname.startsWith('/api/')) {
    if(pathname !== '/api/contact') {res.writeHead(404); return res.end('API not found');}
    const {default:handler}=await import('../api/contact.js');
    return handler(req,res);
  }
  let filepath = path.resolve(pub,'.'+pathname);
  if(!filepath.startsWith(pub+path.sep) && filepath!==pub){res.writeHead(403);return res.end('Forbidden');}
  if(pathname.startsWith('/assets/') && !process.argv.includes('--dist')) filepath=path.join(pub,'public',pathname.slice(1));
  try {
    if((await fs.stat(filepath)).isDirectory()) filepath=path.join(pub,'index.html');
    const data=await fs.readFile(filepath);
    res.writeHead(200,{'Content-Type':mime[path.extname(filepath)]||'application/octet-stream','Cache-Control':pathname.startsWith('/assets/')?'public, max-age=3600':'no-cache'});
    res.end(data);
  } catch {
    if(path.extname(pathname)){res.writeHead(404);res.end('Asset not found');return;}
    const data=await fs.readFile(path.join(pub,'index.html'));
    res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});res.end(data);
  }
}).listen(port,()=>console.log(`Printside ${process.argv.includes('--dist')?'production':'development'} preview: http://localhost:${port}`));
