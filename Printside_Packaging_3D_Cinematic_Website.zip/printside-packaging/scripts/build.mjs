import fs from 'node:fs/promises';
import path from 'node:path';
const root = path.resolve(import.meta.dirname, '..');
const dist = path.join(root, 'dist');
await fs.rm(dist, {recursive:true, force:true});
await fs.mkdir(dist, {recursive:true});
for (const item of ['index.html', 'public', 'src']) {
  const from=path.join(root,item);
  if(item==='public') await fs.cp(from,dist,{recursive:true});
  else await fs.cp(from,path.join(dist,item),{recursive:true});
}
for (const name of ['index.html','src/app.js','src/styles.css','assets/favicon.svg']) await fs.access(path.join(dist,name));
console.log('PASS: built deployable static site at dist/ (no npm install required).');
