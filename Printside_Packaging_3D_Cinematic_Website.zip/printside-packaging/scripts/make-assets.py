from pathlib import Path
p=Path(__file__).resolve().parent.parent / 'public' / 'assets'
(p/'favicon.svg').write_text('''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="14" fill="#06152a"/><path d="M13 22 33 11 52 22 32 34Z" fill="#cfac75"/><path d="M13 22v21l19 11V34Z" fill="#677e97"/><path d="M32 34v20l20-11V22Z" fill="#e4edf4"/><path d="m22 27 21-11" stroke="#071525" stroke-width="2" opacity=".5"/></svg>''')
common='''<defs>
<linearGradient id="back" x2="1" y2="1"><stop stop-color="#1c3550"/><stop offset=".6" stop-color="#0b192e"/><stop offset="1" stop-color="#06101d"/></linearGradient>
<linearGradient id="metal" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#a5b7c5"/><stop offset=".3" stop-color="#4d667a"/><stop offset=".7" stop-color="#1e3347"/><stop offset="1" stop-color="#829caf"/></linearGradient>
<linearGradient id="face" x1="0" x2="1" y2="1"><stop stop-color="#f0ede4"/><stop offset=".5" stop-color="#c6d0d5"/><stop offset="1" stop-color="#627d91"/></linearGradient>
<linearGradient id="gold" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#f3d69a"/><stop offset=".55" stop-color="#bd9061"/><stop offset="1" stop-color="#6d523d"/></linearGradient>
<linearGradient id="floor" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#22384a"/><stop offset="1" stop-color="#091321"/></linearGradient>
<radialGradient id="light"><stop stop-color="#89b0c8" stop-opacity=".45"/><stop offset="1" stop-color="#092037" stop-opacity="0"/></radialGradient>
<filter id="shadow" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="21"/></filter>
<filter id="glow"><feGaussianBlur stdDeviation="5"/></filter>
<pattern id="grid" width="63" height="63" patternUnits="userSpaceOnUse"><path d="M63 0H0V63" fill="none" stroke="#d6e7fa" opacity=".065"/></pattern>
</defs>'''
svg='''<svg xmlns="http://www.w3.org/2000/svg" width="1500" height="950" viewBox="0 0 1500 950">'''+common+'''
<rect width="1500" height="950" fill="url(#back)"/><circle cx="1060" cy="260" r="630" fill="url(#light)"/>
<path d="M0 720 1500 665v285H0Z" fill="url(#floor)"/><path d="M0 760 1500 700M0 850l1500-65M300 730 80 950M740 710 710 950M1190 690l420 300" stroke="#7ea8bc" stroke-width="1.5" opacity=".15"/>
<path d="M0 85H1500M0 170H1500M0 255H1500" stroke="#91b4ca" stroke-width="11" opacity=".12"/><path d="M170 0v645m420-645v650m450-650v645m380-645v650" stroke="#a8c7d8" stroke-width="20" opacity=".09"/>
<g opacity=".36"><path d="M0 150h1500M0 320h1500" stroke="#a5b8c5" stroke-width="3"/><path d="m80 0 230 190M450 0l225 190M860 0l220 190M1190 0l220 190" stroke="#8bafc4" stroke-width="7"/></g>
<ellipse cx="770" cy="754" rx="600" ry="90" fill="#020910" opacity=".75" filter="url(#shadow)"/>
<g transform="translate(200 200)">
<path d="M65 330 1080 300 1220 350 200 390Z" fill="#24394e"/>
<path d="M175 250 1090 240 1160 285 250 305Z" fill="#7e9eaf"/>
<path d="M110 230 1055 218 1100 295 180 315Z" fill="url(#metal)" stroke="#91a8bb" stroke-width="3"/>
<path d="M180 315 1100 295 1110 525 180 548Z" fill="#172c40" stroke="#5d7788" stroke-width="5"/>
<path d="M95 175 1030 158 1085 240 140 255Z" fill="url(#metal)" stroke="#a8bdc7" stroke-width="4"/>
<path d="M140 255 1085 240 1100 305 180 322Z" fill="#0b192b"/>
<path d="M95 175v-25l930-12 58 20-53 21Z" fill="#9eb5c5"/>
<g>'''
for i in range(6):
 x=215+i*145
 svg+=f'''<g><path d="M{x} 176v140l114-2V175Z" fill="url(#face)"/><path d="M{x+12} 204h87v68h-87Z" fill="#20394e" stroke="#92aabd" stroke-width="2"/><path d="M{x+18} 210h73v54h-73Z" fill="#0b1d31"/><circle cx="{x+108}" cy="287" r="5" fill="#e4bd7e"/><path d="M{x+17} 187h45" stroke="#f1f7fa" stroke-width="4" opacity=".7"/></g>'''
svg+='''</g>
<path d="M195 330 1080 310M195 400 1080 378" stroke="#5c8195" stroke-width="6" opacity=".65"/>
<path d="M360 400 950 387v65l-590 8Z" fill="#071524" stroke="#547084" stroke-width="2"/>
<g fill="#9fb2bf"><rect x="275" y="530" width="90" height="38" rx="3"/><rect x="970" y="510" width="105" height="38" rx="3"/></g>
<path d="M76 286 174 280 175 540 88 555Z" fill="#415f73"/><path d="M80 285 125 251 200 260 174 280Z" fill="#c9d4d8"/>
<path d="M1127 263 1192 286 1197 520 1113 518Z" fill="#35566c"/><path d="M1115 260 1136 245 1200 269 1192 286Z" fill="#b0c3cc"/>
<g transform="translate(975 346)"><rect width="97" height="78" rx="5" fill="#657d8c"/><rect x="9" y="9" width="78" height="46" fill="#061522"/><path d="m17 45 19-17 10 10 19-20" fill="none" stroke="#a3d7be" stroke-width="3"/><circle cx="21" cy="66" r="4" fill="#d9b176"/><circle cx="39" cy="66" r="4" fill="#63c59b"/></g>
<g stroke="#a6b9c7" stroke-width="5"><path d="M170 312v212m910-217v209"/><path d="M130 430h1050"/></g>
</g>
<g><path d="M0 450 350 410 320 550 0 602Z" fill="#102437" opacity=".72"/><path d="M1230 399 1500 420v260l-250-65Z" fill="#132a3d" opacity=".7"/></g>
<path d="M0 0H1500V950H0Z" fill="url(#grid)" opacity=".24"/>
</svg>'''
(p/'factory-fallback.svg').write_text(svg)
# product render scene illustration with face-front 3D carton in several variations, purpose: local reliable image assets
items = [
 ('printed-cartons','#d7e2e4','#3c718c','#d2ac70','FOLDING','CARTONS'),
 ('leaf-inserts','#e7e4d9','#8d9eab','#b7b9b0','PRODUCT','INSERTS'),
 ('printed-labels','#e0e9e8','#608b94','#d9aa79','PRINTED','LABELS'),
 ('retail-packaging','#e3d5c4','#bd8162','#bfa586','RETAIL','BOXES'),
 ('tamper-evident','#cbd9d9','#425e83','#d9bb89','SECURITY','SEALS'),
 ('custom-packaging','#d6d9e8','#7775a4','#e1b184','CUSTOM','DESIGN')]
for name,first,second,accent,top,bottom in items:
 product = '''<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="780" viewBox="0 0 1000 780">'''+common+f'''
<rect width="1000" height="780" fill="#101f30"/><circle cx="660" cy="235" r="430" fill="url(#light)"/><path d="M0 610 1000 530V780H0Z" fill="url(#floor)"/><path d="M0 730 1000 620M200 640l-100 140m510-180 100 180" stroke="#91b1c1" opacity=".12"/><ellipse cx="510" cy="631" rx="315" ry="64" fill="#000c19" opacity=".7" filter="url(#shadow)"/>
<g transform="translate(0,-15)">
<path d="M295 210 535 120 760 214 514 310Z" fill="{first}" stroke="#f7f9fa" stroke-width="3"/>
<path d="M295 210 514 310V645L295 538Z" fill="{second}" stroke="#e3eaee" stroke-width="3"/>
<path d="M514 310 760 214V540L514 645Z" fill="{first}" stroke="#f7f9fa" stroke-width="3"/>
<path d="M295 257 514 358v70L295 326Z" fill="{accent}" opacity=".86"/>
<path d="M514 356 760 261v64L514 425Z" fill="{accent}" opacity=".66"/>
<path d="M541 455 735 381M541 477 735 404M541 497 708 433M541 519 680 467" stroke="{second}" stroke-width="7" opacity=".36"/>
<path d="M316 384 493 464M316 405 493 485M316 428l126 57" stroke="#f2f5f4" stroke-width="6" opacity=".42"/>
<path d="M514 310 514 645" stroke="#faf6ec" stroke-width="4" opacity=".72"/>
<path d="M315 219 515 309 746 218" fill="none" stroke="#fff" stroke-opacity=".3" stroke-width="4"/>
<g transform="translate(561 325) skewY(-21)"><rect width="150" height="31" rx="2" fill="{second}" opacity=".17"/><text x="9" y="22" fill="{second}" font-family="Arial,sans-serif" font-size="18" font-weight="bold" letter-spacing="4">PRINTSIDE</text><path d="M10 45h128" stroke="{accent}" stroke-width="5"/></g>
<g transform="translate(326 320) skewY(24)"><text x="0" y="12" fill="#f9f9f7" font-family="Arial,sans-serif" font-size="18" font-weight="bold" letter-spacing="1">{top}</text><text x="0" y="36" fill="#f9f9f7" font-family="Arial,sans-serif" font-size="18" font-weight="bold" letter-spacing="1">{bottom}</text></g>
</g><path d="M0 0H1000V780H0Z" fill="url(#grid)" opacity=".26"/></svg>'''
 (p/f'{name}.svg').write_text(product)
print('SVG assets created',len(list(p.glob('*.svg'))))
