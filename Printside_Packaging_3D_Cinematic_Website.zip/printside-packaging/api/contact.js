/** Vercel serverless contact route. Requires RESEND_API_KEY, CONTACT_TO_EMAIL,
 * CONTACT_FROM_EMAIL. Returns an honest 503 until configured. */
const getText=(v,n=600)=>typeof v==='string'?v.trim().slice(0,n):'';
const escapeHtml=(s)=>s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export default async function handler(req,res){
  res.setHeader('Content-Type','application/json; charset=utf-8');
  res.setHeader('Cache-Control','no-store');
  if(req.method!=='POST'){res.setHeader('Allow','POST');res.statusCode=405;return res.end(JSON.stringify({error:'POST only.'}));}
  let data;
  try {
    if(typeof req.body==='object' && req.body) data=req.body;
    else {let raw='';for await(const part of req){raw+=part;if(raw.length>25000)throw new Error('Too large');} data=JSON.parse(raw);}
  } catch {res.statusCode=400;return res.end(JSON.stringify({error:'Invalid form data.'}));}
  if(data.website){res.statusCode=200;return res.end(JSON.stringify({ok:true}));}
  const name=getText(data.name,100),company=getText(data.company,100),email=getText(data.email,150),phone=getText(data.phone,70),product=getText(data.product,100),message=getText(data.message,4000);
  if(name.length<2||!/^\S+@\S+\.\S+$/.test(email)||message.length<10){res.statusCode=422;return res.end(JSON.stringify({error:'Please provide your name, a valid email and at least 10 characters in your message.'}));}
  const {RESEND_API_KEY, CONTACT_TO_EMAIL, CONTACT_FROM_EMAIL}=process.env;
  if(!RESEND_API_KEY||!CONTACT_TO_EMAIL||!CONTACT_FROM_EMAIL){res.statusCode=503;return res.end(JSON.stringify({error:'Email delivery is not configured yet. The website owner must add the three email environment variables listed in README.md. Your enquiry was not sent.'}));}
  const rows=[['Name',name],['Company',company],['Email',email],['Phone',phone],['Product',product],['Message',message]].map(([label,value])=>`<tr><th style="padding:10px;text-align:left;border-bottom:1px solid #ddd">${label}</th><td style="padding:10px;border-bottom:1px solid #ddd;white-space:pre-wrap">${escapeHtml(value||'—')}</td></tr>`).join('');
  try {
    const response=await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:`Bearer ${RESEND_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({from:CONTACT_FROM_EMAIL,to:[CONTACT_TO_EMAIL],reply_to:email,subject:`Printside enquiry: ${product||'General'} — ${name}`,html:`<h2>New Printside Packaging enquiry</h2><table>${rows}</table>`})});
    if(!response.ok){console.error('Email provider error',response.status);res.statusCode=502;return res.end(JSON.stringify({error:'Email service could not deliver the message. Please try again later.'}));}
    res.statusCode=200;res.end(JSON.stringify({ok:true,message:'Thank you. Your enquiry has been sent.'}));
  }catch(e){console.error('Email service error',e.message);res.statusCode=502;res.end(JSON.stringify({error:'Unable to send enquiry right now. Please try again.'}));}
}
