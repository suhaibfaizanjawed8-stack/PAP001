# Image and artwork sources

The product box graphics and industrial machinery fallback are **original SVG illustrations authored specifically for this website**, bundled under `public/assets/` and freely editable with the website source.

Representative industrial/packaging photography is hosted remotely on images.unsplash.com; individual photo pages report the Unsplash free license. Photo appearance and availability depend on the host and photographer. These are **NOT photos of Printside Packaging's facilities**.

| Image variable | Photographer / account | Source and license information |
| --- | --- | --- |
| `press` | shamin kmrzmn | https://unsplash.com/photos/a-large-machine-in-a-large-room-XJJ5oAZmnlI |
| `motion` | Bank Phrom | https://unsplash.com/photos/printing-machine-Tzm3Oyu_6sk |
| `digital` | Geri Sakti | https://unsplash.com/photos/a-close-up-of-a-conveyor-belt-in-a-factory-KAO2-CRZXTE |
| `rollers` | Aleksandr Galichkin | https://unsplash.com/photos/industrial-printing-press-with-purple-ink-rollers-QRykXu51r_0 |
| `automation` | Anonymous Fox | https://unsplash.com/photos/complex-industrial-machinery-with-robotic-arms-W0wonxdZsbI |
| `warehouse` | Jacques Dillies | https://unsplash.com/photos/warehouse-shelving-with-cardboard-boxes-jcav1COVvOc |
| `kraft` | Grupo Seripafer | https://unsplash.com/photos/brown-and-white-cardboard-box-g2oHJrqcJlQ |
| `robotics` | Cemrecan Yurtman | https://unsplash.com/photos/a-man-working-on-a-machine-in-a-factory-YtAd61sAbGQ |
| `precision` | André Robillard | https://unsplash.com/photos/black-and-white-industrial-machine-tajjW9PxsFQ |

License details: https://unsplash.com/license . For final commercial deployment, you may keep compliant remote photography or replace it with your licensed factory/product photography. Avoid implying that representative photography depicts the user's actual facilities.
