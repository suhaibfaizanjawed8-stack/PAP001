# PRINTSIDE PACKAGING — Premium Cinematic Website

A complete, responsive, deployable website with eight core pages and six linked product detail views, lightweight CSS 3D imagery, product filtering, cinematic parallax, mobile navigation, and a serverless contact form.

## Why this build uses plain JavaScript instead of React/Vite

The preferred stack in the brief was React/Vite, but not mandatory. This implementation intentionally uses native ES modules, CSS and Node.js **without third-party runtime dependencies**. That makes it easier to edit, fast to serve, and enables a verified production build even without installing packages. There are no background videos or heavy 3D engines. JavaScript handles interactive 3D CSS transforms, routing and product filtering. If your developer prefers React, these modular functions can be converted to React components later.

## Quick start

1. Install Node.js 18+.
2. Open this folder in VS Code or a terminal.
3. Run `npm run dev` — open http://localhost:4173.
4. Run `npm run build` — output is in `dist/`.
5. Run `npm run preview` to test the production version.

No `npm install` is required. No packages need to be downloaded.

## Edit the website

- `src/app.js`: all page content, product names, links, routing and interactions.
- `src/styles.css`: typography, colors, layout, 3D hover and motion styling.
- `public/assets/`: locally bundled SVG product mockups and printing facility fallback.
- `index.html`: HTML metadata and optional Google Fonts.
- `api/contact.js`: secure serverless email submission.
- `vercel.json`: Vercel SPA rewrites and production configuration.

### Replace placeholder information

The website name is **Printside Packaging**. The following must be confirmed and added before public launch:

1. Actual company description, registered business name, address, email, phone, WhatsApp URL and social profiles.
2. Actual product range, manufacturing facilities, capabilities and materials.
3. Quality certificates (only when independently verified) and accurate compliance claims.
4. Real factory photos or licensed product images if you do not want representative Unsplash imagery or bespoke SVG mockups.
5. Email delivery configuration (see below).

The prototype deliberately makes **no** claims about ISO/FSC certificates, exact capacities, customers or plant equipment. Reference photos portray representative equipment **not Printside's own facility**.

## Contact form — activate real delivery

Contact fields are checked in the browser and validated again on the server. Until email is configured the form **correctly reports that no email was sent**. No misleading fake success.

1. Set up a verified domain and a Resend account (https://resend.com/).
2. In Vercel > your project > Settings > Environment Variables, add:
   - `RESEND_API_KEY` = your private Resend API key
   - `CONTACT_TO_EMAIL` = the real company inbox receiving enquiries
   - `CONTACT_FROM_EMAIL` = a sender on your verified domain, for example `Printside <website@yourdomain.com>`
3. Redeploy and submit a test enquiry, then check the inbox and the Vercel Function logs.

Do not put API keys in `src/app.js`, commit `.env`, or expose secrets in browser code.

## GitHub + Vercel (recommended)

1. Sign into GitHub and create a new repository `printside-packaging`.
2. Upload **all files except the `dist/` folder**. Or run:
   ```sh
   git init
   git add .
   git commit -m "Create Printside Packaging site"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/printside-packaging.git
   git push -u origin main
   ```
3. Sign into https://vercel.com, choose **Add New > Project**, select the repo.
4. The included `vercel.json` config sets `npm run build` and output folder `dist`.
5. Deploy and open the Vercel URL. Test `/about`, `/products/printed-cartons`, `/contact` and refresh on each route; SPA routing is covered by rewrites.
6. Add the three private email environment variables above and redeploy.
7. Add your custom domain in Vercel if desired.

You can also deploy `dist/` to most static web hosts; the `/api/contact` function requires Vercel (or another compatible backend) and SPA deep-route rewriting. Standard static hosts without rewrites need to configure fallback to `index.html`.

## Photography licensing

Representative external photographs are hotlinked to **Unsplash** and were selected from pages marked Free to use under the Unsplash License. The exact original photo-page URLs and photographers are in `PHOTO-CREDITS.md`. Display requires Internet access to Unsplash. Local original SVG mockups render with no Internet access. If remote pictures cannot be loaded, a bundled illustration is shown automatically. For a fully self-hosted photography deployment, replace photo URLs with rights-cleared local JPEG/WebP images. Do not represent representative images as pictures of Printside's own facility.

## Routes

`/`, `/about`, `/products`, `/products/printed-cartons`, `/products/leaf-inserts`, `/products/printed-labels`, `/products/retail-packaging`, `/products/tamper-evident`, `/products/custom-packaging`, `/capabilities`, `/innovation`, `/quality`, `/industries`, `/contact`.

## Accessibility & performance

- All key links and products are keyboard-accessible.
- Mobile menu uses semantic navigation and visible focus states.
- Honors `prefers-reduced-motion`.
- Decorative SVG renders locally.
- Offscreen photos lazy-load, with built-in fallback illustrations.
- Respects hover and touch differences.
- No video background, heavy 3D library or animation dependency.

## Testing

`npm run check` validates source JavaScript. `npm run build` verifies that required production files exist. `npm run preview` starts a static test server that serves all SPA routes and the contact API. Email delivery cannot be verified until your real email service and secrets are connected. On hosts where images.unsplash.com is blocked, local SVG fallback is used; confirm external photography in a browser with network access.
